const { SchemaComposer } = require('graphql-compose');


const schemaComposer = new SchemaComposer();

const { UserQuery, UserMutation } = require('./user');
// const { UserQuery, UserMutation } = require('./login');
const { BookingQuery, BookingMutation } = require('./booking');
const { ListingQuery, ListingMutation } = require('./listing');

schemaComposer.Query.addFields({
  ...UserQuery,
  ...BookingQuery,
  ...ListingQuery,
});

schemaComposer.Mutation.addFields({
  ...UserMutation,
  ...BookingMutation,
  ...ListingMutation,
});

module.exports = schemaComposer.buildSchema();