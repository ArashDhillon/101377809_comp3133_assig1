const BookingModel = require("../models/booking");
const cwm = BookingModel.cwm;
const resolver = function () { };
const BookingQuery = {
  bookingById: cwm.getResolver("findById"),
  bookingByIds: cwm.getResolver("findByIds"),
  bookingOne: cwm.getResolver("findOne"),
  bookingMany: cwm.getResolver("findMany"),
  bookingCount: cwm.getResolver("count"),
  bookingConnection: cwm.getResolver("connection"),
  bookingPagination: cwm.getResolver("pagination"),
};

const BookingMutation = {
  bookingCreateOne: cwm.getResolver("createOne"),
  bookingCreateMany: cwm.getResolver("createMany"),
  bookingUpdateById: cwm.getResolver("updateById"),
  bookingUpdateOne: cwm.getResolver("updateOne"),
  bookingUpdateMany: cwm.getResolver("updateMany"),
  bookingRemoveById: cwm.getResolver("removeById"),
  bookingRemoveOne: cwm.getResolver("removeOne"),
  bookingRemoveMany: cwm.getResolver("removeMany")
};

module.exports = { BookingQuery, BookingMutation };