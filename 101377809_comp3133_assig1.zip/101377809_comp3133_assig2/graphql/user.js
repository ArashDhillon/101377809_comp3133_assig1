const UserModel = require("../models/user");
const cwm = UserModel.cwm;
const resolver = function () { };
const UserQuery = {
  userById: cwm.getResolver("findById"),
  userByIds: cwm.getResolver("findByIds"),
  userOne: cwm.getResolver("findOne"),
  userMany: cwm.getResolver("findMany"),
  userCount: cwm.getResolver("count"),
  userConnection: cwm.getResolver("connection"),
  userPagination: cwm.getResolver("pagination"),
};

const UserMutation = {
  userCreateOne: cwm.getResolver("createOne"),
  userCreateMany: cwm.getResolver("createMany"),
  userUpdateById: cwm.getResolver("updateById"),
  userUpdateOne: cwm.getResolver("updateOne"),
  userUpdateMany: cwm.getResolver("updateMany"),
  userRemoveById: cwm.getResolver("removeById"),
  userRemoveOne: cwm.getResolver("removeOne"),
  userRemoveMany: cwm.getResolver("removeMany")
};

module.exports = { UserQuery, UserMutation };