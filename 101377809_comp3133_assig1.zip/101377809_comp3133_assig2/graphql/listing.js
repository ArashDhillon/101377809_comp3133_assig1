const ListingModel = require("../models/listing");
const cwm = ListingModel.cwm;

const resolver = function () { };
const ListingQuery = {
  listingById: cwm.getResolver("findById"),
  listingByIds: cwm.getResolver("findByIds"),
  listingOne: cwm.getResolver("findOne"),
  listingMany: cwm.getResolver("findMany"),
  listingCount: cwm.getResolver("count"),
  listingConnection: cwm.getResolver("connection"),
  listingPagination: cwm.getResolver("pagination")
};

const ListingMutation = {
  listingCreateOne: cwm.getResolver("createOne"),
  listingCreateMany: cwm.getResolver("createMany"),
  listingUpdateById: cwm.getResolver("updateById"),
  listingUpdateOne: cwm.getResolver("updateOne"),
  listingUpdateMany: cwm.getResolver("updateMany"),
  listingRemoveById: cwm.getResolver("removeById"),
  listingRemoveOne: cwm.getResolver("removeOne"),
  listingRemoveMany: cwm.getResolver("removeMany")
};

module.exports = { ListingQuery, ListingMutation };