const LoginModel = require("../models/login");
const cwm = LoginModel.cwm;
const resolver = function () { };
const LoginQuery = {
  loginById: cwm.getResolver("findById"),
  loginByIds: cwm.getResolver("findByIds"),
  loginOne: cwm.getResolver("findOne"),
  loginMany: cwm.getResolver("findMany"),
  loginCount: cwm.getResolver("count"),
  loginConnection: cwm.getResolver("connection"),
  loginPagination: cwm.getResolver("pagination"),
};

const LoginMutation = {
  loginCreateOne: cwm.getResolver("createOne"),
  loginCreateMany: cwm.getResolver("createMany"),
  loginUpdateById: cwm.getResolver("updateById"),
  loginUpdateOne: cwm.getResolver("updateOne"),
  loginUpdateMany: cwm.getResolver("updateMany"),
  loginRemoveById: cwm.getResolver("removeById"),
  loginRemoveOne: cwm.getResolver("removeOne"),
  loginRemoveMany: cwm.getResolver("removeMany")
};

module.exports = { LoginQuery, LoginMutation };