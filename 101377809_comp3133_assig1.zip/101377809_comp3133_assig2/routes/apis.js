var express = require('express');
var router = express.Router();
const utility = require('../utility');
const passport = require('passport');
const addAuthentication = passport.authenticate('jwt', { session: false });
let LoginModel = require('../models/login');
let UserModel = require('../models/user');
let ListingModel = require('../models/listing');
let BookingModel = require('../models/booking');
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

/**
 * 1.user register
 */
router.post('/register', function (req, res) {
  let { username, firstname, lastname, password, email, type } = req.body;
  if (!username || !firstname || !lastname || !password || !email || !type) {
    return res.json({ success: false, message: 'username, firstname, lastname, password, email, type is required' });
  }

  if (type != 'admin' && type != 'customer') return res.json({ success: false, message: 'type value incorrect' });

  if (!UserModel.validateEmail(email)) return res.json({ success: false, message: 'email invalid' });
  if (!UserModel.validatePassword(password)) return res.json({ success: false, message: 'password invalid' });
  UserModel.findOne({ username }).then(found => {
    if (found) return res.json({ success: false, message: 'username existed' });
    UserModel.create({ email, password: utility.createPassword(password), type, firstname, lastname, username }).then(user => {
      return LoginModel.initSessionFromEmail(user.id);
    }).then((data) => {
      res.json({ success: true, data: data });
    }).catch(err => {
      res.json({ success: false, message: err?.message || err });
    });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

/**
 * 2. user login
 */
router.post('/login', function (req, res) {
  let { username, password } = req.body;
  if (!username || !password) return res.json({ success: false, message: 'email/password is required' });
  UserModel.findOne({ username }).then(user => {
    if (!user) return res.json({ success: false, message: 'user not found' });
    if (user.password != utility.createPassword(password)) return res.json({ success: false, message: 'password incorrect' });
    LoginModel.initSessionFromEmail(user.id).then((data) => {
      res.json({ success: true, data: data });
    });
  });
});

/**
 * 3. admin create listing
 */
router.post('/create_listing', addAuthentication, function (req, res) {
  if (req.user.user.type != UserModel.getUserTypes().admin) return res.json({ success: false, message: 'permission denied' });
  let { listing_id, listing_title, description, street, city, postal_code, price, email, username } = req.body;
  if (!listing_id || !listing_title || !description || !street || !city || !postal_code || price == undefined || !email || !username) {
    return res.json({ success: false, message: 'listing_id, listing_title, description, street, city, postal_code, price, email, username is required' });
  }

  if (!UserModel.validateEmail(email)) {
    return res.json({ success: false, message: 'email invalid' });
  }
  ListingModel.findOne({ listing_id }).then(found => {
    if (found) return res.json({ success: false, message: 'listing_id existed' });
    return ListingModel.create({ listing_id, listing_title, description, street, city, postal_code, price, email, username }).then((listing) => {
      res.json({ success: true, data: listing });
    });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

/**
 * 4.get listings
 */
router.get('/listings', function (req, res) {
  ListingModel.find({}).then(data => {
    res.json({ success: true, data });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

/** 
 * 5. user booking listing
*/
router.post('/booking', addAuthentication, function (req, res) {
  let { listing_id } = req.body;
  if (!listing_id) return res.json({ success: false, message: 'listing_id is required' });
  ListingModel.findOne({ listing_id }).then(found => {
    if (!found) return res.json({ success: false, message: 'listing not found.' });

    return BookingModel.create({ listing_id, listing_fk: found.id, user: req.user.user.id }).then(data => {
      res.json({ success: true, data });
    });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});


/**
 * 6. search listings 
 */
router.post('/listings', function (req, res) {
  let { search } = req.body;
  let filter = {};
  if (search.name) filter['$and'] = [{ $or: [{ listing_title: { $regex: search.name, $options: 'i' } }, { description: { $regex: search.name, $options: 'i' } }] }];
  else if (search.city) {
    filter['$and'] = [{ $or: [{ city: { $regex: search.city, $options: 'i' } }, { postal_code: { $regex: search.name, $options: 'i' } }] }];
  }

  if (search.name && search.city) {
    filter['$and'] = [{ $or: [{ listing_title: { $regex: search.name, $options: 'i' } }, { description: { $regex: search.name, $options: 'i' } }] }, { $or: [{ city: { $regex: search.city, $options: 'i' } }, { postal_code: { $regex: search.name, $options: 'i' } }] }];

  }

  ListingModel.find(filter).then(data => {
    res.json({ success: true, data });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

/** 
 * 7. get bookings by user
*/
router.get('/bookings', addAuthentication, function (req, res) {
  let username = req.user.username;
  let filter = { username };
  BookingModel.find(filter).then(founds => {
    res.json({ success: true, data: founds });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

/**
 * 8.
 */
router.get('/listings_by_admin', addAuthentication, function (req, res) {
  let username = req.user.user.username;
  let filter = { username };
  ListingModel.find(filter).then(data => {
    res.json({ success: true, data });
  }).catch(err => {
    res.json({ success: false, message: err?.message || err });
  });
});

module.exports = router;
