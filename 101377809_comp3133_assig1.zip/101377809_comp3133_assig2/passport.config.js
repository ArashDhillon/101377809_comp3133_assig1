const passport = require('passport');
let JwtStrategy = require('passport-jwt').Strategy;
let ExtractJwt = require('passport-jwt').ExtractJwt;
let mongoose = require('mongoose');
let Constant = require('./constant');
const LoginModel = require('./models/login');
const UserModel = require('./models/user');
const debug = require('debug')(Constant.debug_name + ':passport');
const cookieExtractor = function (req) {
	let token = ExtractJwt.fromAuthHeaderAsBearerToken();
	token = token(req) || req.cookies['jwt'] || req.headers['authorization'] || req.cookies.token || req.body.token || req.query.token;
	return token;
};

const config = function (passport) {
	let opts = {};
	opts.jwtFromRequest = cookieExtractor;
	opts.secretOrKey = Constant.secrectKey;
	const jwtHandler = new JwtStrategy(opts, function (jwtPayload, done) {
		if (!jwtPayload) return done(null, false);

		LoginModel.findOne({ _id: mongoose.Types.ObjectId(jwtPayload), isExpired: 0 })
			.populate({ path: 'user', model: UserModel.name, select: '-password' })
			.then((login) => {
				if (!login) return done(null, false);
				return done(null, login);
			})
			.catch(done);
	});
	passport.use('jwt', jwtHandler);
};

function setupAuthenticate(app) {
	config(passport);
	app.use(passport.initialize());
	app.use(passport.session());
	// app.use(
	// 	passport.session({
	// 		secret: Constant.secrectKey,
	// 		cookie: { maxAge: 24 * 60 * 1000 },
	// 		resave: false,
	// 		saveUninitialized: false,
	// 		maxAge: 24 * 60 * 1000, // 24 hours
	// 	}),
	// );

	passport.serializeUser(function (user, done) {
		done(null, { _id: user._id });
	});

	passport.deserializeUser(function (user, done) {
		if (!user || !user._id) return done(null, false);
		LoginModel.findById(user._id, done).populate({ path: 'user', model: UserModel.name, select: '-password' });
	});
}
module.exports = setupAuthenticate;
