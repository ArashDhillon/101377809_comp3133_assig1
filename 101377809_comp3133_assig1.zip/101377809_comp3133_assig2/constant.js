var uri = "mongodb://students:students@cluster0-shard-00-00.fivtn.mongodb.net:27017,cluster0-shard-00-01.fivtn.mongodb.net:27017,cluster0-shard-00-02.fivtn.mongodb.net:27017/101377809_comp3133_assig1?ssl=true&replicaSet=atlas-lzi1dj-shard-0&authSource=admin&retryWrites=true&w=majority";

module.exports = {
  debug_name: 'graphql',
  secrectKey: 'studentId_comp3133_assig1',
  uri_mongodb: uri
  // uri_mongodb: "mongodb+srv://students:students@cluster0.fivtn.mongodb.net/students?retryWrites=true&w=majority"
};