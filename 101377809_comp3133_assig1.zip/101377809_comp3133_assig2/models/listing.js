
const mongoose = require('mongoose');
const { composeWithMongoose } = require('graphql-compose-mongoose');
let { Model, Schema } = mongoose;

const ListingSchema = new Schema(
  {
    listing_id: { type: String, require: true, unique: true },
    listing_title: { type: String, require: true, },
    description: { type: String, maxLength: 1000, require: true },
    street: { type: String, require: true, },
    city: { type: String, require: true, },
    postal_code: { type: String, require: true, },
    price: { type: Number, require: true, },
    email: {
      type: String,
      lowercase: true,
      trim: true,
      require: true,
      validate: {
        validator: function (v) {
          return /^([\w-\.]+@([\w-]+\.)+[\w-]{2,})?$/.test(v);
        },
        message: 'Email invalid',
      },
      required: [/^([\w-\.]+@([\w-]+\.)+[\w-]{2,})?$/, 'Email invalid'],
    },
    username: { type: String, require: true, },
  }
);
class ListingModel extends Model {
}

let toExport = mongoose.models[ListingModel.name];
if (!toExport) {
  toExport = mongoose.model(ListingModel, ListingSchema, null, ListingSchema);
  toExport.cwm = composeWithMongoose(toExport);
}
module.exports = toExport;
