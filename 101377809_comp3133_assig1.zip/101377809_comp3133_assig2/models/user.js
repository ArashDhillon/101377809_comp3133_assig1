
const mongoose = require('mongoose');
const { composeWithMongoose } = require('graphql-compose-mongoose');
const UserTypes = {
  customer: 'customer',
  admin: 'admin'
};
let { Model, Schema } = mongoose;
const UserSchema = new Schema(
  {
    username: { type: String, lowercase: true, trim: true, unique: true },
    firstname: { type: String, required: true, trim: true },
    lastname: { type: String, required: true, trim: true },
    email: {
      type: String,
      lowercase: true,
      trim: true,
      unique: true,
      validate: {
        validator: function (v) {
          return /^([\w-\.]+@([\w-]+\.)+[\w-]{2,})?$/.test(v);
        },
        message: 'Email invalid',
      },
      required: [/^([\w-\.]+@([\w-]+\.)+[\w-]{2,})?$/, 'Email invalid'],
    },
    password: {
      type: String,
      required: true,
      validate: {
        validator: function (v) {
          return /^[A-Za-z0-9#$&_]{6,}$/gmi.test(v);
        },
        message: 'password invalid',
      },
    },
    type: {
      type: String,
      require: true,
      trim: true,
      validate: {
        validator: function (v) {
          return ['admin', 'customer'].includes(v);
        },
        message: 'type invalid',
      }
    }
  }
);

class UserModel extends Model {
  static getUserTypes() {
    return UserTypes;
  }

  static validatePassword(password) {
    let regex = /^[A-Za-z0-9#$&_]{6,}$/gmi;
    return password && regex.test(password);
  }
  static validateEmail(email) {
    return email && /^([\w-\.]+@([\w-]+\.)+[\w-]{2,})?$/.test(email);
  }
}
let toExport = mongoose.models[UserModel.name];
if (!toExport) {
  toExport = mongoose.model(UserModel, UserSchema, null, UserModel);
  toExport.cwm = composeWithMongoose(toExport);
}

module.exports = toExport;
