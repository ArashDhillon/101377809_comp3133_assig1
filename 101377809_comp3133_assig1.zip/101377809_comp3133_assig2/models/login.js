const mongoose = require('mongoose');
const { composeWithMongoose } = require('graphql-compose-mongoose');
const constant = require('../constant');
const UserModel = require('./User');
const UserRole = UserModel.getUserTypes();
const jwt = require('jsonwebtoken');

var { Model, Schema } = mongoose;

const LoginSchema = new Schema({
	user: { type: Schema.Types.ObjectId, ref: 'UserModel' },
	token: { type: String, unique: true },
	timeLogin: { type: Date, default: Date.now },
	isExpired: { type: Number, default: 0 }
});
class LoginModel extends Model {
	static async initSessionFromEmail(userId) {
		const newSession = new LoginModel();
		newSession.user = userId;
		newSession.token = jwt.sign(newSession.id.toString(), constant.secrectKey);
		// await newSession.save();
		return newSession.save().then((doc) => {
			return doc.populate({ path: 'user', model: UserModel.name, select: '-password' }).execPopulate();
		});
		console.log(newSession);
		// return newSession;

		// return LoginModel.create({ id: newSession.id, user: userId, token: jwt.sign(newSession.id.toString(), constant.secrectKey) });
	}
}

// mongoose.model(LoginModel, LoginSchema);
// module.exports = LoginModel;

let toExport = mongoose.models[LoginModel.name];
if (!toExport) {
	toExport = mongoose.model(LoginModel, LoginSchema, null, LoginSchema);
	toExport.cwm = composeWithMongoose(toExport);
}
module.exports = toExport;
