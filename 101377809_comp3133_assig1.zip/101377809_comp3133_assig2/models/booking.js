
const mongoose = require('mongoose');
const { composeWithMongoose } = require('graphql-compose-mongoose');
let { Model, Schema } = mongoose;

const BookingSchema = new Schema(
  {
    listing_id: { type: String, require: true },
    booking_id: { type: String, require: true, unique: true },
    booking_date: { type: Date, require: true, default: Date.now },
    booking_start: { type: Date, require: true, default: Date.now },
    booking_end: { type: Date, require: true, default: Date.now },
    username: { type: String, require: true },
  }
);
class BookingModel extends Model {
  static findBookingByUser(username) {
    return [];
  }
}

// module.exports = mongoose.model(BookingModel, BookingSchema);
let toExport = mongoose.models[BookingModel.name];
if (!toExport) {
  toExport = mongoose.model(BookingModel, BookingSchema, null, BookingSchema);
  toExport.cwm = composeWithMongoose(toExport);
}
module.exports = toExport;
