let crypto = require('crypto');

module.exports = {

  // createPassword: password => crypto.createHash('md5').update(password).digest('hex')
  createPassword: password => password
};